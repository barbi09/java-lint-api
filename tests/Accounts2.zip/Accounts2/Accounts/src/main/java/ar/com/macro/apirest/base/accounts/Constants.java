package ar.com.macro.apirest.base.accounts;


public class Constants {
    // Operaciones
    public static final String OP_GET_LIST = "get-list";
    public static final String OP_GET_BALANCE = "get-balance";
    public static final String OP_GET_DETAIL= "get-detail";
    public static final String OP_GET_MOVEMENTS = "get-movements";
	public static final String PEPE = "get-movements";

}
